jQuery.sap.declare("com.nbcu.util.Formatter");

com.nbcu.util.Formatter = {

    defaultImage: function(sStr) {
    	alert(sStr);
        return sStr.toUpperCase();
    }

};